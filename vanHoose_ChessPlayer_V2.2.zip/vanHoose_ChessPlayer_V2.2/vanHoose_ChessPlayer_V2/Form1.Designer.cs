﻿namespace vanHoose_ChessPlayer_V2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.w_Pawn1 = new System.Windows.Forms.Label();
            this.w_Pawn8 = new System.Windows.Forms.Label();
            this.w_Pawn7 = new System.Windows.Forms.Label();
            this.w_Pawn6 = new System.Windows.Forms.Label();
            this.w_Pawn5 = new System.Windows.Forms.Label();
            this.w_Pawn4 = new System.Windows.Forms.Label();
            this.w_Pawn3 = new System.Windows.Forms.Label();
            this.w_Pawn2 = new System.Windows.Forms.Label();
            this.b_Pawn2 = new System.Windows.Forms.Label();
            this.b_Pawn3 = new System.Windows.Forms.Label();
            this.b_Pawn4 = new System.Windows.Forms.Label();
            this.b_Pawn5 = new System.Windows.Forms.Label();
            this.b_Pawn6 = new System.Windows.Forms.Label();
            this.b_Pawn7 = new System.Windows.Forms.Label();
            this.b_Pawn8 = new System.Windows.Forms.Label();
            this.b_Pawn1 = new System.Windows.Forms.Label();
            this.w_Knight1 = new System.Windows.Forms.Label();
            this.w_Bishop1 = new System.Windows.Forms.Label();
            this.w_King = new System.Windows.Forms.Label();
            this.w_Queen = new System.Windows.Forms.Label();
            this.w_Bishop2 = new System.Windows.Forms.Label();
            this.w_Knight2 = new System.Windows.Forms.Label();
            this.w_Rook2 = new System.Windows.Forms.Label();
            this.w_Rook1 = new System.Windows.Forms.Label();
            this.b_Knight1 = new System.Windows.Forms.Label();
            this.b_Bishop1 = new System.Windows.Forms.Label();
            this.b_Queen = new System.Windows.Forms.Label();
            this.b_King = new System.Windows.Forms.Label();
            this.b_Bishop2 = new System.Windows.Forms.Label();
            this.b_Knight2 = new System.Windows.Forms.Label();
            this.b_Rook2 = new System.Windows.Forms.Label();
            this.b_Rook1 = new System.Windows.Forms.Label();
            this.sqr00 = new System.Windows.Forms.PictureBox();
            this.sqr01 = new System.Windows.Forms.PictureBox();
            this.sqr02 = new System.Windows.Forms.PictureBox();
            this.sqr03 = new System.Windows.Forms.PictureBox();
            this.sqr04 = new System.Windows.Forms.PictureBox();
            this.sqr05 = new System.Windows.Forms.PictureBox();
            this.sqr06 = new System.Windows.Forms.PictureBox();
            this.sqr07 = new System.Windows.Forms.PictureBox();
            this.sqr16 = new System.Windows.Forms.PictureBox();
            this.sqr17 = new System.Windows.Forms.PictureBox();
            this.sqr14 = new System.Windows.Forms.PictureBox();
            this.sqr15 = new System.Windows.Forms.PictureBox();
            this.sqr12 = new System.Windows.Forms.PictureBox();
            this.sqr13 = new System.Windows.Forms.PictureBox();
            this.sqr10 = new System.Windows.Forms.PictureBox();
            this.sqr11 = new System.Windows.Forms.PictureBox();
            this.sqr36 = new System.Windows.Forms.PictureBox();
            this.sqr37 = new System.Windows.Forms.PictureBox();
            this.sqr34 = new System.Windows.Forms.PictureBox();
            this.sqr35 = new System.Windows.Forms.PictureBox();
            this.sqr32 = new System.Windows.Forms.PictureBox();
            this.sqr33 = new System.Windows.Forms.PictureBox();
            this.sqr30 = new System.Windows.Forms.PictureBox();
            this.sqr31 = new System.Windows.Forms.PictureBox();
            this.sqr26 = new System.Windows.Forms.PictureBox();
            this.sqr27 = new System.Windows.Forms.PictureBox();
            this.sqr24 = new System.Windows.Forms.PictureBox();
            this.sqr25 = new System.Windows.Forms.PictureBox();
            this.sqr22 = new System.Windows.Forms.PictureBox();
            this.sqr23 = new System.Windows.Forms.PictureBox();
            this.sqr20 = new System.Windows.Forms.PictureBox();
            this.sqr21 = new System.Windows.Forms.PictureBox();
            this.sqr76 = new System.Windows.Forms.PictureBox();
            this.sqr77 = new System.Windows.Forms.PictureBox();
            this.sqr74 = new System.Windows.Forms.PictureBox();
            this.sqr75 = new System.Windows.Forms.PictureBox();
            this.sqr72 = new System.Windows.Forms.PictureBox();
            this.sqr73 = new System.Windows.Forms.PictureBox();
            this.sqr70 = new System.Windows.Forms.PictureBox();
            this.sqr71 = new System.Windows.Forms.PictureBox();
            this.sqr66 = new System.Windows.Forms.PictureBox();
            this.sqr67 = new System.Windows.Forms.PictureBox();
            this.sqr64 = new System.Windows.Forms.PictureBox();
            this.sqr65 = new System.Windows.Forms.PictureBox();
            this.sqr62 = new System.Windows.Forms.PictureBox();
            this.sqr63 = new System.Windows.Forms.PictureBox();
            this.sqr60 = new System.Windows.Forms.PictureBox();
            this.sqr61 = new System.Windows.Forms.PictureBox();
            this.sqr56 = new System.Windows.Forms.PictureBox();
            this.sqr57 = new System.Windows.Forms.PictureBox();
            this.sqr54 = new System.Windows.Forms.PictureBox();
            this.sqr55 = new System.Windows.Forms.PictureBox();
            this.sqr52 = new System.Windows.Forms.PictureBox();
            this.sqr53 = new System.Windows.Forms.PictureBox();
            this.sqr50 = new System.Windows.Forms.PictureBox();
            this.sqr51 = new System.Windows.Forms.PictureBox();
            this.sqr46 = new System.Windows.Forms.PictureBox();
            this.sqr47 = new System.Windows.Forms.PictureBox();
            this.sqr44 = new System.Windows.Forms.PictureBox();
            this.sqr45 = new System.Windows.Forms.PictureBox();
            this.sqr42 = new System.Windows.Forms.PictureBox();
            this.sqr43 = new System.Windows.Forms.PictureBox();
            this.sqr40 = new System.Windows.Forms.PictureBox();
            this.sqr41 = new System.Windows.Forms.PictureBox();
            this.btn_playCC = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.cmd_mode = new System.Windows.Forms.ComboBox();
            this.lst_stats = new System.Windows.Forms.ListBox();
            this.btn_PlayHH = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.sqr00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr41)).BeginInit();
            this.SuspendLayout();
            // 
            // w_Pawn1
            // 
            this.w_Pawn1.AutoSize = true;
            this.w_Pawn1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Pawn1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Pawn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Pawn1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Pawn1.Location = new System.Drawing.Point(11, 76);
            this.w_Pawn1.Name = "w_Pawn1";
            this.w_Pawn1.Size = new System.Drawing.Size(42, 40);
            this.w_Pawn1.TabIndex = 1;
            this.w_Pawn1.Tag = "WP1";
            this.w_Pawn1.Text = "P";
            this.w_Pawn1.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_Pawn8
            // 
            this.w_Pawn8.AutoSize = true;
            this.w_Pawn8.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Pawn8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Pawn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Pawn8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Pawn8.Location = new System.Drawing.Point(459, 76);
            this.w_Pawn8.Name = "w_Pawn8";
            this.w_Pawn8.Size = new System.Drawing.Size(42, 40);
            this.w_Pawn8.TabIndex = 2;
            this.w_Pawn8.Tag = "WP8";
            this.w_Pawn8.Text = "P";
            this.w_Pawn8.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_Pawn7
            // 
            this.w_Pawn7.AutoSize = true;
            this.w_Pawn7.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Pawn7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Pawn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Pawn7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Pawn7.Location = new System.Drawing.Point(395, 76);
            this.w_Pawn7.Name = "w_Pawn7";
            this.w_Pawn7.Size = new System.Drawing.Size(42, 40);
            this.w_Pawn7.TabIndex = 3;
            this.w_Pawn7.Tag = "WP7";
            this.w_Pawn7.Text = "P";
            this.w_Pawn7.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_Pawn6
            // 
            this.w_Pawn6.AutoSize = true;
            this.w_Pawn6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Pawn6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Pawn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Pawn6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Pawn6.Location = new System.Drawing.Point(331, 76);
            this.w_Pawn6.Name = "w_Pawn6";
            this.w_Pawn6.Size = new System.Drawing.Size(42, 40);
            this.w_Pawn6.TabIndex = 4;
            this.w_Pawn6.Tag = "WP6";
            this.w_Pawn6.Text = "P";
            this.w_Pawn6.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_Pawn5
            // 
            this.w_Pawn5.AutoSize = true;
            this.w_Pawn5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Pawn5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Pawn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Pawn5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Pawn5.Location = new System.Drawing.Point(267, 76);
            this.w_Pawn5.Name = "w_Pawn5";
            this.w_Pawn5.Size = new System.Drawing.Size(42, 40);
            this.w_Pawn5.TabIndex = 5;
            this.w_Pawn5.Tag = "WP5";
            this.w_Pawn5.Text = "P";
            this.w_Pawn5.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_Pawn4
            // 
            this.w_Pawn4.AutoSize = true;
            this.w_Pawn4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Pawn4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Pawn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Pawn4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Pawn4.Location = new System.Drawing.Point(203, 76);
            this.w_Pawn4.Name = "w_Pawn4";
            this.w_Pawn4.Size = new System.Drawing.Size(42, 40);
            this.w_Pawn4.TabIndex = 6;
            this.w_Pawn4.Tag = "WP4";
            this.w_Pawn4.Text = "P";
            this.w_Pawn4.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_Pawn3
            // 
            this.w_Pawn3.AutoSize = true;
            this.w_Pawn3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Pawn3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Pawn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Pawn3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Pawn3.Location = new System.Drawing.Point(139, 76);
            this.w_Pawn3.Name = "w_Pawn3";
            this.w_Pawn3.Size = new System.Drawing.Size(42, 40);
            this.w_Pawn3.TabIndex = 7;
            this.w_Pawn3.Tag = "WP3";
            this.w_Pawn3.Text = "P";
            this.w_Pawn3.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_Pawn2
            // 
            this.w_Pawn2.AutoSize = true;
            this.w_Pawn2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Pawn2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Pawn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Pawn2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Pawn2.Location = new System.Drawing.Point(75, 76);
            this.w_Pawn2.Name = "w_Pawn2";
            this.w_Pawn2.Size = new System.Drawing.Size(42, 40);
            this.w_Pawn2.TabIndex = 8;
            this.w_Pawn2.Tag = "WP2";
            this.w_Pawn2.Text = "P";
            this.w_Pawn2.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Pawn2
            // 
            this.b_Pawn2.AutoSize = true;
            this.b_Pawn2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Pawn2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Pawn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Pawn2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Pawn2.Location = new System.Drawing.Point(75, 396);
            this.b_Pawn2.Name = "b_Pawn2";
            this.b_Pawn2.Size = new System.Drawing.Size(42, 40);
            this.b_Pawn2.TabIndex = 16;
            this.b_Pawn2.Tag = "BP2";
            this.b_Pawn2.Text = "P";
            this.b_Pawn2.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Pawn3
            // 
            this.b_Pawn3.AutoSize = true;
            this.b_Pawn3.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Pawn3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Pawn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Pawn3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Pawn3.Location = new System.Drawing.Point(139, 396);
            this.b_Pawn3.Name = "b_Pawn3";
            this.b_Pawn3.Size = new System.Drawing.Size(42, 40);
            this.b_Pawn3.TabIndex = 15;
            this.b_Pawn3.Tag = "BP3";
            this.b_Pawn3.Text = "P";
            this.b_Pawn3.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Pawn4
            // 
            this.b_Pawn4.AutoSize = true;
            this.b_Pawn4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Pawn4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Pawn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Pawn4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Pawn4.Location = new System.Drawing.Point(203, 396);
            this.b_Pawn4.Name = "b_Pawn4";
            this.b_Pawn4.Size = new System.Drawing.Size(42, 40);
            this.b_Pawn4.TabIndex = 14;
            this.b_Pawn4.Tag = "BP4";
            this.b_Pawn4.Text = "P";
            this.b_Pawn4.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Pawn5
            // 
            this.b_Pawn5.AutoSize = true;
            this.b_Pawn5.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Pawn5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Pawn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Pawn5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Pawn5.Location = new System.Drawing.Point(267, 396);
            this.b_Pawn5.Name = "b_Pawn5";
            this.b_Pawn5.Size = new System.Drawing.Size(42, 40);
            this.b_Pawn5.TabIndex = 13;
            this.b_Pawn5.Tag = "BP5";
            this.b_Pawn5.Text = "P";
            this.b_Pawn5.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Pawn6
            // 
            this.b_Pawn6.AutoSize = true;
            this.b_Pawn6.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Pawn6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Pawn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Pawn6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Pawn6.Location = new System.Drawing.Point(331, 396);
            this.b_Pawn6.Name = "b_Pawn6";
            this.b_Pawn6.Size = new System.Drawing.Size(42, 40);
            this.b_Pawn6.TabIndex = 12;
            this.b_Pawn6.Tag = "BP6";
            this.b_Pawn6.Text = "P";
            this.b_Pawn6.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Pawn7
            // 
            this.b_Pawn7.AutoSize = true;
            this.b_Pawn7.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Pawn7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Pawn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Pawn7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Pawn7.Location = new System.Drawing.Point(395, 396);
            this.b_Pawn7.Name = "b_Pawn7";
            this.b_Pawn7.Size = new System.Drawing.Size(42, 40);
            this.b_Pawn7.TabIndex = 11;
            this.b_Pawn7.Tag = "BP7";
            this.b_Pawn7.Text = "P";
            this.b_Pawn7.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Pawn8
            // 
            this.b_Pawn8.AutoSize = true;
            this.b_Pawn8.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Pawn8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Pawn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Pawn8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Pawn8.Location = new System.Drawing.Point(459, 396);
            this.b_Pawn8.Name = "b_Pawn8";
            this.b_Pawn8.Size = new System.Drawing.Size(42, 40);
            this.b_Pawn8.TabIndex = 10;
            this.b_Pawn8.Tag = "BP8";
            this.b_Pawn8.Text = "P";
            this.b_Pawn8.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Pawn1
            // 
            this.b_Pawn1.AutoSize = true;
            this.b_Pawn1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Pawn1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Pawn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Pawn1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Pawn1.Location = new System.Drawing.Point(11, 396);
            this.b_Pawn1.Name = "b_Pawn1";
            this.b_Pawn1.Size = new System.Drawing.Size(42, 40);
            this.b_Pawn1.TabIndex = 9;
            this.b_Pawn1.Tag = "BP1";
            this.b_Pawn1.Text = "P";
            this.b_Pawn1.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_Knight1
            // 
            this.w_Knight1.AutoSize = true;
            this.w_Knight1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Knight1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Knight1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Knight1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Knight1.Location = new System.Drawing.Point(75, 12);
            this.w_Knight1.Name = "w_Knight1";
            this.w_Knight1.Size = new System.Drawing.Size(44, 40);
            this.w_Knight1.TabIndex = 24;
            this.w_Knight1.Tag = "WN1";
            this.w_Knight1.Text = "N";
            this.w_Knight1.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_Bishop1
            // 
            this.w_Bishop1.AutoSize = true;
            this.w_Bishop1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Bishop1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Bishop1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Bishop1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Bishop1.Location = new System.Drawing.Point(139, 12);
            this.w_Bishop1.Name = "w_Bishop1";
            this.w_Bishop1.Size = new System.Drawing.Size(42, 40);
            this.w_Bishop1.TabIndex = 23;
            this.w_Bishop1.Tag = "WH1";
            this.w_Bishop1.Text = "B";
            this.w_Bishop1.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_King
            // 
            this.w_King.AutoSize = true;
            this.w_King.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_King.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_King.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_King.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_King.Location = new System.Drawing.Point(203, 12);
            this.w_King.Name = "w_King";
            this.w_King.Size = new System.Drawing.Size(42, 40);
            this.w_King.TabIndex = 22;
            this.w_King.Tag = "WK1";
            this.w_King.Text = "K";
            this.w_King.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_Queen
            // 
            this.w_Queen.AutoSize = true;
            this.w_Queen.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Queen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Queen.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Queen.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Queen.Location = new System.Drawing.Point(267, 12);
            this.w_Queen.Name = "w_Queen";
            this.w_Queen.Size = new System.Drawing.Size(46, 40);
            this.w_Queen.TabIndex = 21;
            this.w_Queen.Tag = "WQ1";
            this.w_Queen.Text = "Q";
            this.w_Queen.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_Bishop2
            // 
            this.w_Bishop2.AutoSize = true;
            this.w_Bishop2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Bishop2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Bishop2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Bishop2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Bishop2.Location = new System.Drawing.Point(331, 12);
            this.w_Bishop2.Name = "w_Bishop2";
            this.w_Bishop2.Size = new System.Drawing.Size(42, 40);
            this.w_Bishop2.TabIndex = 20;
            this.w_Bishop2.Tag = "WH2";
            this.w_Bishop2.Text = "B";
            this.w_Bishop2.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_Knight2
            // 
            this.w_Knight2.AutoSize = true;
            this.w_Knight2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Knight2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Knight2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Knight2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Knight2.Location = new System.Drawing.Point(395, 12);
            this.w_Knight2.Name = "w_Knight2";
            this.w_Knight2.Size = new System.Drawing.Size(44, 40);
            this.w_Knight2.TabIndex = 19;
            this.w_Knight2.Tag = "WN2";
            this.w_Knight2.Text = "N";
            this.w_Knight2.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_Rook2
            // 
            this.w_Rook2.AutoSize = true;
            this.w_Rook2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Rook2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Rook2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Rook2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Rook2.Location = new System.Drawing.Point(459, 12);
            this.w_Rook2.Name = "w_Rook2";
            this.w_Rook2.Size = new System.Drawing.Size(44, 40);
            this.w_Rook2.TabIndex = 18;
            this.w_Rook2.Tag = "WR2";
            this.w_Rook2.Text = "R";
            this.w_Rook2.Click += new System.EventHandler(this.highLiteMove);
            // 
            // w_Rook1
            // 
            this.w_Rook1.AutoSize = true;
            this.w_Rook1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.w_Rook1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.w_Rook1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_Rook1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.w_Rook1.Location = new System.Drawing.Point(11, 12);
            this.w_Rook1.Name = "w_Rook1";
            this.w_Rook1.Size = new System.Drawing.Size(44, 40);
            this.w_Rook1.TabIndex = 17;
            this.w_Rook1.Tag = "WR1";
            this.w_Rook1.Text = "R";
            this.w_Rook1.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Knight1
            // 
            this.b_Knight1.AutoSize = true;
            this.b_Knight1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Knight1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Knight1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Knight1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Knight1.Location = new System.Drawing.Point(75, 460);
            this.b_Knight1.Name = "b_Knight1";
            this.b_Knight1.Size = new System.Drawing.Size(44, 40);
            this.b_Knight1.TabIndex = 32;
            this.b_Knight1.Tag = "BN1";
            this.b_Knight1.Text = "N";
            this.b_Knight1.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Bishop1
            // 
            this.b_Bishop1.AutoSize = true;
            this.b_Bishop1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Bishop1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Bishop1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Bishop1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Bishop1.Location = new System.Drawing.Point(139, 460);
            this.b_Bishop1.Name = "b_Bishop1";
            this.b_Bishop1.Size = new System.Drawing.Size(42, 40);
            this.b_Bishop1.TabIndex = 31;
            this.b_Bishop1.Tag = "BH1";
            this.b_Bishop1.Text = "B";
            this.b_Bishop1.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Queen
            // 
            this.b_Queen.AutoSize = true;
            this.b_Queen.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Queen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Queen.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Queen.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Queen.Location = new System.Drawing.Point(203, 460);
            this.b_Queen.Name = "b_Queen";
            this.b_Queen.Size = new System.Drawing.Size(46, 40);
            this.b_Queen.TabIndex = 30;
            this.b_Queen.Tag = "BQ1";
            this.b_Queen.Text = "Q";
            this.b_Queen.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_King
            // 
            this.b_King.AutoSize = true;
            this.b_King.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_King.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_King.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_King.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_King.Location = new System.Drawing.Point(267, 460);
            this.b_King.Name = "b_King";
            this.b_King.Size = new System.Drawing.Size(42, 40);
            this.b_King.TabIndex = 29;
            this.b_King.Tag = "BK1";
            this.b_King.Text = "K";
            this.b_King.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Bishop2
            // 
            this.b_Bishop2.AutoSize = true;
            this.b_Bishop2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Bishop2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Bishop2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Bishop2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Bishop2.Location = new System.Drawing.Point(331, 460);
            this.b_Bishop2.Name = "b_Bishop2";
            this.b_Bishop2.Size = new System.Drawing.Size(42, 40);
            this.b_Bishop2.TabIndex = 28;
            this.b_Bishop2.Tag = "BH2";
            this.b_Bishop2.Text = "B";
            this.b_Bishop2.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Knight2
            // 
            this.b_Knight2.AutoSize = true;
            this.b_Knight2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Knight2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Knight2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Knight2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Knight2.Location = new System.Drawing.Point(395, 460);
            this.b_Knight2.Name = "b_Knight2";
            this.b_Knight2.Size = new System.Drawing.Size(44, 40);
            this.b_Knight2.TabIndex = 27;
            this.b_Knight2.Tag = "BN2";
            this.b_Knight2.Text = "N";
            this.b_Knight2.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Rook2
            // 
            this.b_Rook2.AutoSize = true;
            this.b_Rook2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Rook2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Rook2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Rook2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Rook2.Location = new System.Drawing.Point(459, 460);
            this.b_Rook2.Name = "b_Rook2";
            this.b_Rook2.Size = new System.Drawing.Size(44, 40);
            this.b_Rook2.TabIndex = 26;
            this.b_Rook2.Tag = "BR2";
            this.b_Rook2.Text = "R";
            this.b_Rook2.Click += new System.EventHandler(this.highLiteMove);
            // 
            // b_Rook1
            // 
            this.b_Rook1.AutoSize = true;
            this.b_Rook1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.b_Rook1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.b_Rook1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_Rook1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.b_Rook1.Location = new System.Drawing.Point(11, 460);
            this.b_Rook1.Name = "b_Rook1";
            this.b_Rook1.Size = new System.Drawing.Size(44, 40);
            this.b_Rook1.TabIndex = 25;
            this.b_Rook1.Tag = "BR1";
            this.b_Rook1.Text = "R";
            this.b_Rook1.Click += new System.EventHandler(this.highLiteMove);
            // 
            // sqr00
            // 
            this.sqr00.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr00.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr00.Location = new System.Drawing.Point(0, 0);
            this.sqr00.Name = "sqr00";
            this.sqr00.Size = new System.Drawing.Size(64, 64);
            this.sqr00.TabIndex = 33;
            this.sqr00.TabStop = false;
            this.sqr00.Tag = "B00";
            this.sqr00.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr01
            // 
            this.sqr01.BackColor = System.Drawing.Color.White;
            this.sqr01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr01.Location = new System.Drawing.Point(64, 0);
            this.sqr01.Name = "sqr01";
            this.sqr01.Size = new System.Drawing.Size(64, 64);
            this.sqr01.TabIndex = 35;
            this.sqr01.TabStop = false;
            this.sqr01.Tag = "W01";
            this.sqr01.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr02
            // 
            this.sqr02.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr02.Location = new System.Drawing.Point(128, 0);
            this.sqr02.Name = "sqr02";
            this.sqr02.Size = new System.Drawing.Size(64, 64);
            this.sqr02.TabIndex = 36;
            this.sqr02.TabStop = false;
            this.sqr02.Tag = "B02";
            this.sqr02.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr03
            // 
            this.sqr03.BackColor = System.Drawing.Color.White;
            this.sqr03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr03.Location = new System.Drawing.Point(192, 0);
            this.sqr03.Name = "sqr03";
            this.sqr03.Size = new System.Drawing.Size(64, 64);
            this.sqr03.TabIndex = 37;
            this.sqr03.TabStop = false;
            this.sqr03.Tag = "W03";
            this.sqr03.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr04
            // 
            this.sqr04.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr04.Location = new System.Drawing.Point(256, 0);
            this.sqr04.Name = "sqr04";
            this.sqr04.Size = new System.Drawing.Size(64, 64);
            this.sqr04.TabIndex = 38;
            this.sqr04.TabStop = false;
            this.sqr04.Tag = "B04";
            this.sqr04.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr05
            // 
            this.sqr05.BackColor = System.Drawing.Color.White;
            this.sqr05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr05.Location = new System.Drawing.Point(320, 0);
            this.sqr05.Name = "sqr05";
            this.sqr05.Size = new System.Drawing.Size(64, 64);
            this.sqr05.TabIndex = 39;
            this.sqr05.TabStop = false;
            this.sqr05.Tag = "W05";
            this.sqr05.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr06
            // 
            this.sqr06.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr06.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr06.Location = new System.Drawing.Point(384, 0);
            this.sqr06.Name = "sqr06";
            this.sqr06.Size = new System.Drawing.Size(64, 64);
            this.sqr06.TabIndex = 40;
            this.sqr06.TabStop = false;
            this.sqr06.Tag = "B06";
            this.sqr06.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr07
            // 
            this.sqr07.BackColor = System.Drawing.Color.White;
            this.sqr07.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr07.Location = new System.Drawing.Point(448, 0);
            this.sqr07.Name = "sqr07";
            this.sqr07.Size = new System.Drawing.Size(64, 64);
            this.sqr07.TabIndex = 41;
            this.sqr07.TabStop = false;
            this.sqr07.Tag = "W07";
            this.sqr07.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr16
            // 
            this.sqr16.BackColor = System.Drawing.Color.White;
            this.sqr16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr16.Location = new System.Drawing.Point(384, 64);
            this.sqr16.Name = "sqr16";
            this.sqr16.Size = new System.Drawing.Size(64, 64);
            this.sqr16.TabIndex = 48;
            this.sqr16.TabStop = false;
            this.sqr16.Tag = "W16";
            this.sqr16.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr17
            // 
            this.sqr17.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr17.Location = new System.Drawing.Point(448, 64);
            this.sqr17.Name = "sqr17";
            this.sqr17.Size = new System.Drawing.Size(64, 64);
            this.sqr17.TabIndex = 49;
            this.sqr17.TabStop = false;
            this.sqr17.Tag = "B17";
            this.sqr17.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr14
            // 
            this.sqr14.BackColor = System.Drawing.Color.White;
            this.sqr14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr14.Location = new System.Drawing.Point(256, 64);
            this.sqr14.Name = "sqr14";
            this.sqr14.Size = new System.Drawing.Size(64, 64);
            this.sqr14.TabIndex = 46;
            this.sqr14.TabStop = false;
            this.sqr14.Tag = "W14";
            this.sqr14.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr15
            // 
            this.sqr15.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr15.Location = new System.Drawing.Point(320, 64);
            this.sqr15.Name = "sqr15";
            this.sqr15.Size = new System.Drawing.Size(64, 64);
            this.sqr15.TabIndex = 47;
            this.sqr15.TabStop = false;
            this.sqr15.Tag = "B15";
            this.sqr15.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr12
            // 
            this.sqr12.BackColor = System.Drawing.Color.White;
            this.sqr12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr12.Location = new System.Drawing.Point(128, 64);
            this.sqr12.Name = "sqr12";
            this.sqr12.Size = new System.Drawing.Size(64, 64);
            this.sqr12.TabIndex = 44;
            this.sqr12.TabStop = false;
            this.sqr12.Tag = "W12";
            this.sqr12.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr13
            // 
            this.sqr13.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr13.Location = new System.Drawing.Point(192, 64);
            this.sqr13.Name = "sqr13";
            this.sqr13.Size = new System.Drawing.Size(64, 64);
            this.sqr13.TabIndex = 45;
            this.sqr13.TabStop = false;
            this.sqr13.Tag = "B13";
            this.sqr13.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr10
            // 
            this.sqr10.BackColor = System.Drawing.Color.White;
            this.sqr10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr10.Location = new System.Drawing.Point(0, 64);
            this.sqr10.Name = "sqr10";
            this.sqr10.Size = new System.Drawing.Size(64, 64);
            this.sqr10.TabIndex = 42;
            this.sqr10.TabStop = false;
            this.sqr10.Tag = "W10";
            this.sqr10.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr11
            // 
            this.sqr11.BackColor = System.Drawing.Color.Black;
            this.sqr11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr11.Location = new System.Drawing.Point(64, 64);
            this.sqr11.Name = "sqr11";
            this.sqr11.Size = new System.Drawing.Size(64, 64);
            this.sqr11.TabIndex = 43;
            this.sqr11.TabStop = false;
            this.sqr11.Tag = "B11";
            this.sqr11.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr36
            // 
            this.sqr36.BackColor = System.Drawing.Color.White;
            this.sqr36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr36.Location = new System.Drawing.Point(384, 192);
            this.sqr36.Name = "sqr36";
            this.sqr36.Size = new System.Drawing.Size(64, 64);
            this.sqr36.TabIndex = 64;
            this.sqr36.TabStop = false;
            this.sqr36.Tag = "W36";
            this.sqr36.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr37
            // 
            this.sqr37.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr37.Location = new System.Drawing.Point(448, 192);
            this.sqr37.Name = "sqr37";
            this.sqr37.Size = new System.Drawing.Size(64, 64);
            this.sqr37.TabIndex = 65;
            this.sqr37.TabStop = false;
            this.sqr37.Tag = "B37";
            this.sqr37.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr34
            // 
            this.sqr34.BackColor = System.Drawing.Color.White;
            this.sqr34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr34.Location = new System.Drawing.Point(256, 192);
            this.sqr34.Name = "sqr34";
            this.sqr34.Size = new System.Drawing.Size(64, 64);
            this.sqr34.TabIndex = 62;
            this.sqr34.TabStop = false;
            this.sqr34.Tag = "W34";
            this.sqr34.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr35
            // 
            this.sqr35.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr35.Location = new System.Drawing.Point(320, 192);
            this.sqr35.Name = "sqr35";
            this.sqr35.Size = new System.Drawing.Size(64, 64);
            this.sqr35.TabIndex = 63;
            this.sqr35.TabStop = false;
            this.sqr35.Tag = "B35";
            this.sqr35.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr32
            // 
            this.sqr32.BackColor = System.Drawing.Color.White;
            this.sqr32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr32.Location = new System.Drawing.Point(128, 192);
            this.sqr32.Name = "sqr32";
            this.sqr32.Size = new System.Drawing.Size(64, 64);
            this.sqr32.TabIndex = 60;
            this.sqr32.TabStop = false;
            this.sqr32.Tag = "W32";
            this.sqr32.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr33
            // 
            this.sqr33.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr33.Location = new System.Drawing.Point(192, 192);
            this.sqr33.Name = "sqr33";
            this.sqr33.Size = new System.Drawing.Size(64, 64);
            this.sqr33.TabIndex = 61;
            this.sqr33.TabStop = false;
            this.sqr33.Tag = "B33";
            this.sqr33.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr30
            // 
            this.sqr30.BackColor = System.Drawing.Color.White;
            this.sqr30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr30.Location = new System.Drawing.Point(0, 192);
            this.sqr30.Name = "sqr30";
            this.sqr30.Size = new System.Drawing.Size(64, 64);
            this.sqr30.TabIndex = 58;
            this.sqr30.TabStop = false;
            this.sqr30.Tag = "W30";
            this.sqr30.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr31
            // 
            this.sqr31.BackColor = System.Drawing.Color.Black;
            this.sqr31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr31.Location = new System.Drawing.Point(64, 192);
            this.sqr31.Name = "sqr31";
            this.sqr31.Size = new System.Drawing.Size(64, 64);
            this.sqr31.TabIndex = 59;
            this.sqr31.TabStop = false;
            this.sqr31.Tag = "B31";
            this.sqr31.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr26
            // 
            this.sqr26.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr26.Location = new System.Drawing.Point(384, 128);
            this.sqr26.Name = "sqr26";
            this.sqr26.Size = new System.Drawing.Size(64, 64);
            this.sqr26.TabIndex = 56;
            this.sqr26.TabStop = false;
            this.sqr26.Tag = "B26";
            this.sqr26.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr27
            // 
            this.sqr27.BackColor = System.Drawing.Color.White;
            this.sqr27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr27.Location = new System.Drawing.Point(448, 128);
            this.sqr27.Name = "sqr27";
            this.sqr27.Size = new System.Drawing.Size(64, 64);
            this.sqr27.TabIndex = 57;
            this.sqr27.TabStop = false;
            this.sqr27.Tag = "W27";
            this.sqr27.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr24
            // 
            this.sqr24.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr24.Location = new System.Drawing.Point(256, 128);
            this.sqr24.Name = "sqr24";
            this.sqr24.Size = new System.Drawing.Size(64, 64);
            this.sqr24.TabIndex = 54;
            this.sqr24.TabStop = false;
            this.sqr24.Tag = "B24";
            this.sqr24.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr25
            // 
            this.sqr25.BackColor = System.Drawing.Color.White;
            this.sqr25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr25.Location = new System.Drawing.Point(320, 128);
            this.sqr25.Name = "sqr25";
            this.sqr25.Size = new System.Drawing.Size(64, 64);
            this.sqr25.TabIndex = 55;
            this.sqr25.TabStop = false;
            this.sqr25.Tag = "W25";
            this.sqr25.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr22
            // 
            this.sqr22.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr22.Location = new System.Drawing.Point(128, 128);
            this.sqr22.Name = "sqr22";
            this.sqr22.Size = new System.Drawing.Size(64, 64);
            this.sqr22.TabIndex = 52;
            this.sqr22.TabStop = false;
            this.sqr22.Tag = "B22";
            this.sqr22.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr23
            // 
            this.sqr23.BackColor = System.Drawing.Color.White;
            this.sqr23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr23.Location = new System.Drawing.Point(192, 128);
            this.sqr23.Name = "sqr23";
            this.sqr23.Size = new System.Drawing.Size(64, 64);
            this.sqr23.TabIndex = 53;
            this.sqr23.TabStop = false;
            this.sqr23.Tag = "W23";
            this.sqr23.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr20
            // 
            this.sqr20.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr20.Location = new System.Drawing.Point(0, 128);
            this.sqr20.Name = "sqr20";
            this.sqr20.Size = new System.Drawing.Size(64, 64);
            this.sqr20.TabIndex = 50;
            this.sqr20.TabStop = false;
            this.sqr20.Tag = "B20";
            this.sqr20.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr21
            // 
            this.sqr21.BackColor = System.Drawing.Color.White;
            this.sqr21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr21.Location = new System.Drawing.Point(64, 128);
            this.sqr21.Name = "sqr21";
            this.sqr21.Size = new System.Drawing.Size(64, 64);
            this.sqr21.TabIndex = 51;
            this.sqr21.TabStop = false;
            this.sqr21.Tag = "W21";
            this.sqr21.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr76
            // 
            this.sqr76.BackColor = System.Drawing.Color.White;
            this.sqr76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr76.Location = new System.Drawing.Point(384, 448);
            this.sqr76.Name = "sqr76";
            this.sqr76.Size = new System.Drawing.Size(64, 64);
            this.sqr76.TabIndex = 96;
            this.sqr76.TabStop = false;
            this.sqr76.Tag = "W76";
            this.sqr76.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr77
            // 
            this.sqr77.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr77.Location = new System.Drawing.Point(448, 448);
            this.sqr77.Name = "sqr77";
            this.sqr77.Size = new System.Drawing.Size(64, 64);
            this.sqr77.TabIndex = 97;
            this.sqr77.TabStop = false;
            this.sqr77.Tag = "B77";
            this.sqr77.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr74
            // 
            this.sqr74.BackColor = System.Drawing.Color.White;
            this.sqr74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr74.Location = new System.Drawing.Point(256, 448);
            this.sqr74.Name = "sqr74";
            this.sqr74.Size = new System.Drawing.Size(64, 64);
            this.sqr74.TabIndex = 94;
            this.sqr74.TabStop = false;
            this.sqr74.Tag = "W74";
            this.sqr74.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr75
            // 
            this.sqr75.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr75.Location = new System.Drawing.Point(320, 448);
            this.sqr75.Name = "sqr75";
            this.sqr75.Size = new System.Drawing.Size(64, 64);
            this.sqr75.TabIndex = 95;
            this.sqr75.TabStop = false;
            this.sqr75.Tag = "B75";
            this.sqr75.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr72
            // 
            this.sqr72.BackColor = System.Drawing.Color.White;
            this.sqr72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr72.Location = new System.Drawing.Point(128, 448);
            this.sqr72.Name = "sqr72";
            this.sqr72.Size = new System.Drawing.Size(64, 64);
            this.sqr72.TabIndex = 92;
            this.sqr72.TabStop = false;
            this.sqr72.Tag = "W72";
            this.sqr72.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr73
            // 
            this.sqr73.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr73.Location = new System.Drawing.Point(192, 448);
            this.sqr73.Name = "sqr73";
            this.sqr73.Size = new System.Drawing.Size(64, 64);
            this.sqr73.TabIndex = 93;
            this.sqr73.TabStop = false;
            this.sqr73.Tag = "B73";
            this.sqr73.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr70
            // 
            this.sqr70.BackColor = System.Drawing.Color.White;
            this.sqr70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr70.Location = new System.Drawing.Point(0, 448);
            this.sqr70.Name = "sqr70";
            this.sqr70.Size = new System.Drawing.Size(64, 64);
            this.sqr70.TabIndex = 90;
            this.sqr70.TabStop = false;
            this.sqr70.Tag = "W70";
            this.sqr70.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr71
            // 
            this.sqr71.BackColor = System.Drawing.Color.Black;
            this.sqr71.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr71.Location = new System.Drawing.Point(64, 448);
            this.sqr71.Name = "sqr71";
            this.sqr71.Size = new System.Drawing.Size(64, 64);
            this.sqr71.TabIndex = 91;
            this.sqr71.TabStop = false;
            this.sqr71.Tag = "B71";
            this.sqr71.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr66
            // 
            this.sqr66.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr66.Location = new System.Drawing.Point(384, 384);
            this.sqr66.Name = "sqr66";
            this.sqr66.Size = new System.Drawing.Size(64, 64);
            this.sqr66.TabIndex = 88;
            this.sqr66.TabStop = false;
            this.sqr66.Tag = "B66";
            this.sqr66.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr67
            // 
            this.sqr67.BackColor = System.Drawing.Color.White;
            this.sqr67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr67.Location = new System.Drawing.Point(448, 384);
            this.sqr67.Name = "sqr67";
            this.sqr67.Size = new System.Drawing.Size(64, 64);
            this.sqr67.TabIndex = 89;
            this.sqr67.TabStop = false;
            this.sqr67.Tag = "W67";
            this.sqr67.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr64
            // 
            this.sqr64.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr64.Location = new System.Drawing.Point(256, 384);
            this.sqr64.Name = "sqr64";
            this.sqr64.Size = new System.Drawing.Size(64, 64);
            this.sqr64.TabIndex = 86;
            this.sqr64.TabStop = false;
            this.sqr64.Tag = "B64";
            this.sqr64.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr65
            // 
            this.sqr65.BackColor = System.Drawing.Color.White;
            this.sqr65.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr65.Location = new System.Drawing.Point(320, 384);
            this.sqr65.Name = "sqr65";
            this.sqr65.Size = new System.Drawing.Size(64, 64);
            this.sqr65.TabIndex = 87;
            this.sqr65.TabStop = false;
            this.sqr65.Tag = "W65";
            this.sqr65.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr62
            // 
            this.sqr62.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr62.Location = new System.Drawing.Point(128, 384);
            this.sqr62.Name = "sqr62";
            this.sqr62.Size = new System.Drawing.Size(64, 64);
            this.sqr62.TabIndex = 84;
            this.sqr62.TabStop = false;
            this.sqr62.Tag = "B62";
            this.sqr62.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr63
            // 
            this.sqr63.BackColor = System.Drawing.Color.White;
            this.sqr63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr63.Location = new System.Drawing.Point(192, 384);
            this.sqr63.Name = "sqr63";
            this.sqr63.Size = new System.Drawing.Size(64, 64);
            this.sqr63.TabIndex = 85;
            this.sqr63.TabStop = false;
            this.sqr63.Tag = "W63";
            this.sqr63.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr60
            // 
            this.sqr60.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr60.Location = new System.Drawing.Point(0, 384);
            this.sqr60.Name = "sqr60";
            this.sqr60.Size = new System.Drawing.Size(64, 64);
            this.sqr60.TabIndex = 82;
            this.sqr60.TabStop = false;
            this.sqr60.Tag = "B60";
            this.sqr60.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr61
            // 
            this.sqr61.BackColor = System.Drawing.Color.White;
            this.sqr61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr61.Location = new System.Drawing.Point(64, 384);
            this.sqr61.Name = "sqr61";
            this.sqr61.Size = new System.Drawing.Size(64, 64);
            this.sqr61.TabIndex = 83;
            this.sqr61.TabStop = false;
            this.sqr61.Tag = "W61";
            this.sqr61.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr56
            // 
            this.sqr56.BackColor = System.Drawing.Color.White;
            this.sqr56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr56.Location = new System.Drawing.Point(384, 320);
            this.sqr56.Name = "sqr56";
            this.sqr56.Size = new System.Drawing.Size(64, 64);
            this.sqr56.TabIndex = 80;
            this.sqr56.TabStop = false;
            this.sqr56.Tag = "W56";
            this.sqr56.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr57
            // 
            this.sqr57.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr57.Location = new System.Drawing.Point(448, 320);
            this.sqr57.Name = "sqr57";
            this.sqr57.Size = new System.Drawing.Size(64, 64);
            this.sqr57.TabIndex = 81;
            this.sqr57.TabStop = false;
            this.sqr57.Tag = "B57";
            this.sqr57.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr54
            // 
            this.sqr54.BackColor = System.Drawing.Color.White;
            this.sqr54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr54.Location = new System.Drawing.Point(256, 320);
            this.sqr54.Name = "sqr54";
            this.sqr54.Size = new System.Drawing.Size(64, 64);
            this.sqr54.TabIndex = 78;
            this.sqr54.TabStop = false;
            this.sqr54.Tag = "W54";
            this.sqr54.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr55
            // 
            this.sqr55.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr55.Location = new System.Drawing.Point(320, 320);
            this.sqr55.Name = "sqr55";
            this.sqr55.Size = new System.Drawing.Size(64, 64);
            this.sqr55.TabIndex = 79;
            this.sqr55.TabStop = false;
            this.sqr55.Tag = "B55";
            this.sqr55.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr52
            // 
            this.sqr52.BackColor = System.Drawing.Color.White;
            this.sqr52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr52.Location = new System.Drawing.Point(128, 320);
            this.sqr52.Name = "sqr52";
            this.sqr52.Size = new System.Drawing.Size(64, 64);
            this.sqr52.TabIndex = 76;
            this.sqr52.TabStop = false;
            this.sqr52.Tag = "W52";
            this.sqr52.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr53
            // 
            this.sqr53.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr53.Location = new System.Drawing.Point(192, 320);
            this.sqr53.Name = "sqr53";
            this.sqr53.Size = new System.Drawing.Size(64, 64);
            this.sqr53.TabIndex = 77;
            this.sqr53.TabStop = false;
            this.sqr53.Tag = "B53";
            this.sqr53.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr50
            // 
            this.sqr50.BackColor = System.Drawing.Color.White;
            this.sqr50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr50.Location = new System.Drawing.Point(0, 320);
            this.sqr50.Name = "sqr50";
            this.sqr50.Size = new System.Drawing.Size(64, 64);
            this.sqr50.TabIndex = 74;
            this.sqr50.TabStop = false;
            this.sqr50.Tag = "W50";
            this.sqr50.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr51
            // 
            this.sqr51.BackColor = System.Drawing.Color.Black;
            this.sqr51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr51.Location = new System.Drawing.Point(64, 320);
            this.sqr51.Name = "sqr51";
            this.sqr51.Size = new System.Drawing.Size(64, 64);
            this.sqr51.TabIndex = 75;
            this.sqr51.TabStop = false;
            this.sqr51.Tag = "B51";
            this.sqr51.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr46
            // 
            this.sqr46.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr46.Location = new System.Drawing.Point(384, 256);
            this.sqr46.Name = "sqr46";
            this.sqr46.Size = new System.Drawing.Size(64, 64);
            this.sqr46.TabIndex = 72;
            this.sqr46.TabStop = false;
            this.sqr46.Tag = "B46";
            this.sqr46.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr47
            // 
            this.sqr47.BackColor = System.Drawing.Color.White;
            this.sqr47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr47.Location = new System.Drawing.Point(448, 256);
            this.sqr47.Name = "sqr47";
            this.sqr47.Size = new System.Drawing.Size(64, 64);
            this.sqr47.TabIndex = 73;
            this.sqr47.TabStop = false;
            this.sqr47.Tag = "W47";
            this.sqr47.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr44
            // 
            this.sqr44.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr44.Location = new System.Drawing.Point(256, 256);
            this.sqr44.Name = "sqr44";
            this.sqr44.Size = new System.Drawing.Size(64, 64);
            this.sqr44.TabIndex = 70;
            this.sqr44.TabStop = false;
            this.sqr44.Tag = "B44";
            this.sqr44.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr45
            // 
            this.sqr45.BackColor = System.Drawing.Color.White;
            this.sqr45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr45.Location = new System.Drawing.Point(320, 256);
            this.sqr45.Name = "sqr45";
            this.sqr45.Size = new System.Drawing.Size(64, 64);
            this.sqr45.TabIndex = 71;
            this.sqr45.TabStop = false;
            this.sqr45.Tag = "W45";
            this.sqr45.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr42
            // 
            this.sqr42.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr42.Location = new System.Drawing.Point(128, 256);
            this.sqr42.Name = "sqr42";
            this.sqr42.Size = new System.Drawing.Size(64, 64);
            this.sqr42.TabIndex = 68;
            this.sqr42.TabStop = false;
            this.sqr42.Tag = "B42";
            this.sqr42.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr43
            // 
            this.sqr43.BackColor = System.Drawing.Color.White;
            this.sqr43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr43.Location = new System.Drawing.Point(192, 256);
            this.sqr43.Name = "sqr43";
            this.sqr43.Size = new System.Drawing.Size(64, 64);
            this.sqr43.TabIndex = 69;
            this.sqr43.TabStop = false;
            this.sqr43.Tag = "W43";
            this.sqr43.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr40
            // 
            this.sqr40.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sqr40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr40.Location = new System.Drawing.Point(0, 256);
            this.sqr40.Name = "sqr40";
            this.sqr40.Size = new System.Drawing.Size(64, 64);
            this.sqr40.TabIndex = 66;
            this.sqr40.TabStop = false;
            this.sqr40.Tag = "B40";
            this.sqr40.Click += new System.EventHandler(this.selectMove);
            // 
            // sqr41
            // 
            this.sqr41.BackColor = System.Drawing.Color.White;
            this.sqr41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqr41.Location = new System.Drawing.Point(64, 256);
            this.sqr41.Name = "sqr41";
            this.sqr41.Size = new System.Drawing.Size(64, 64);
            this.sqr41.TabIndex = 67;
            this.sqr41.TabStop = false;
            this.sqr41.Tag = "W41";
            this.sqr41.Click += new System.EventHandler(this.selectMove);
            // 
            // btn_playCC
            // 
            this.btn_playCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_playCC.Location = new System.Drawing.Point(23, 526);
            this.btn_playCC.Name = "btn_playCC";
            this.btn_playCC.Size = new System.Drawing.Size(233, 63);
            this.btn_playCC.TabIndex = 100;
            this.btn_playCC.Text = "Start Computer vs. Computer";
            this.btn_playCC.UseVisualStyleBackColor = true;
            this.btn_playCC.Click += new System.EventHandler(this.btn_playCC_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(541, 526);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(145, 63);
            this.btn_reset.TabIndex = 101;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // cmd_mode
            // 
            this.cmd_mode.FormattingEnabled = true;
            this.cmd_mode.Items.AddRange(new object[] {
            "Human vs. Human",
            "Computer vs. Computer"});
            this.cmd_mode.Location = new System.Drawing.Point(541, 38);
            this.cmd_mode.Name = "cmd_mode";
            this.cmd_mode.Size = new System.Drawing.Size(121, 21);
            this.cmd_mode.TabIndex = 102;
            this.cmd_mode.SelectionChangeCommitted += new System.EventHandler(this.cmd_mode_SelectionChangeCommitted);
            // 
            // lst_stats
            // 
            this.lst_stats.BackColor = System.Drawing.Color.Sienna;
            this.lst_stats.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_stats.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.lst_stats.FormattingEnabled = true;
            this.lst_stats.ItemHeight = 24;
            this.lst_stats.Items.AddRange(new object[] {
            "Current Player",
            "[White]",
            "",
            "White Pieces",
            "16",
            "",
            "Black Pieces",
            "16",
            "",
            "White Wins",
            "0",
            "",
            "Black Wins",
            "0"});
            this.lst_stats.Location = new System.Drawing.Point(521, 76);
            this.lst_stats.Name = "lst_stats";
            this.lst_stats.Size = new System.Drawing.Size(168, 412);
            this.lst_stats.TabIndex = 103;
            // 
            // btn_PlayHH
            // 
            this.btn_PlayHH.Enabled = false;
            this.btn_PlayHH.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PlayHH.Location = new System.Drawing.Point(267, 526);
            this.btn_PlayHH.Name = "btn_PlayHH";
            this.btn_PlayHH.Size = new System.Drawing.Size(264, 63);
            this.btn_PlayHH.TabIndex = 104;
            this.btn_PlayHH.Text = "Start Human vs. Human";
            this.btn_PlayHH.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.Sienna;
            this.listBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Items.AddRange(new object[] {
            "Select Mode"});
            this.listBox1.Location = new System.Drawing.Point(541, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(106, 20);
            this.listBox1.TabIndex = 105;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Sienna;
            this.ClientSize = new System.Drawing.Size(698, 601);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.btn_PlayHH);
            this.Controls.Add(this.lst_stats);
            this.Controls.Add(this.cmd_mode);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_playCC);
            this.Controls.Add(this.b_Knight1);
            this.Controls.Add(this.b_Bishop1);
            this.Controls.Add(this.b_Queen);
            this.Controls.Add(this.b_King);
            this.Controls.Add(this.b_Bishop2);
            this.Controls.Add(this.b_Knight2);
            this.Controls.Add(this.b_Rook2);
            this.Controls.Add(this.b_Rook1);
            this.Controls.Add(this.w_Knight1);
            this.Controls.Add(this.w_Bishop1);
            this.Controls.Add(this.w_King);
            this.Controls.Add(this.w_Queen);
            this.Controls.Add(this.w_Bishop2);
            this.Controls.Add(this.w_Knight2);
            this.Controls.Add(this.w_Rook2);
            this.Controls.Add(this.w_Rook1);
            this.Controls.Add(this.b_Pawn2);
            this.Controls.Add(this.b_Pawn3);
            this.Controls.Add(this.b_Pawn4);
            this.Controls.Add(this.b_Pawn5);
            this.Controls.Add(this.b_Pawn6);
            this.Controls.Add(this.b_Pawn7);
            this.Controls.Add(this.b_Pawn8);
            this.Controls.Add(this.b_Pawn1);
            this.Controls.Add(this.w_Pawn2);
            this.Controls.Add(this.w_Pawn3);
            this.Controls.Add(this.w_Pawn4);
            this.Controls.Add(this.w_Pawn5);
            this.Controls.Add(this.w_Pawn6);
            this.Controls.Add(this.w_Pawn7);
            this.Controls.Add(this.w_Pawn8);
            this.Controls.Add(this.w_Pawn1);
            this.Controls.Add(this.sqr76);
            this.Controls.Add(this.sqr77);
            this.Controls.Add(this.sqr74);
            this.Controls.Add(this.sqr75);
            this.Controls.Add(this.sqr72);
            this.Controls.Add(this.sqr73);
            this.Controls.Add(this.sqr70);
            this.Controls.Add(this.sqr71);
            this.Controls.Add(this.sqr66);
            this.Controls.Add(this.sqr67);
            this.Controls.Add(this.sqr64);
            this.Controls.Add(this.sqr65);
            this.Controls.Add(this.sqr62);
            this.Controls.Add(this.sqr63);
            this.Controls.Add(this.sqr60);
            this.Controls.Add(this.sqr61);
            this.Controls.Add(this.sqr56);
            this.Controls.Add(this.sqr57);
            this.Controls.Add(this.sqr54);
            this.Controls.Add(this.sqr55);
            this.Controls.Add(this.sqr52);
            this.Controls.Add(this.sqr53);
            this.Controls.Add(this.sqr50);
            this.Controls.Add(this.sqr51);
            this.Controls.Add(this.sqr46);
            this.Controls.Add(this.sqr47);
            this.Controls.Add(this.sqr44);
            this.Controls.Add(this.sqr45);
            this.Controls.Add(this.sqr42);
            this.Controls.Add(this.sqr43);
            this.Controls.Add(this.sqr40);
            this.Controls.Add(this.sqr41);
            this.Controls.Add(this.sqr36);
            this.Controls.Add(this.sqr37);
            this.Controls.Add(this.sqr34);
            this.Controls.Add(this.sqr35);
            this.Controls.Add(this.sqr32);
            this.Controls.Add(this.sqr33);
            this.Controls.Add(this.sqr30);
            this.Controls.Add(this.sqr31);
            this.Controls.Add(this.sqr26);
            this.Controls.Add(this.sqr27);
            this.Controls.Add(this.sqr24);
            this.Controls.Add(this.sqr25);
            this.Controls.Add(this.sqr22);
            this.Controls.Add(this.sqr23);
            this.Controls.Add(this.sqr20);
            this.Controls.Add(this.sqr21);
            this.Controls.Add(this.sqr16);
            this.Controls.Add(this.sqr17);
            this.Controls.Add(this.sqr14);
            this.Controls.Add(this.sqr15);
            this.Controls.Add(this.sqr12);
            this.Controls.Add(this.sqr13);
            this.Controls.Add(this.sqr10);
            this.Controls.Add(this.sqr11);
            this.Controls.Add(this.sqr06);
            this.Controls.Add(this.sqr07);
            this.Controls.Add(this.sqr04);
            this.Controls.Add(this.sqr05);
            this.Controls.Add(this.sqr02);
            this.Controls.Add(this.sqr03);
            this.Controls.Add(this.sqr00);
            this.Controls.Add(this.sqr01);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Chess Sharp";
            this.Click += new System.EventHandler(this.highLiteMove);
            ((System.ComponentModel.ISupportInitialize)(this.sqr00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sqr41)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label w_Pawn1;
        private System.Windows.Forms.Label w_Pawn8;
        private System.Windows.Forms.Label w_Pawn7;
        private System.Windows.Forms.Label w_Pawn6;
        private System.Windows.Forms.Label w_Pawn5;
        private System.Windows.Forms.Label w_Pawn4;
        private System.Windows.Forms.Label w_Pawn3;
        private System.Windows.Forms.Label w_Pawn2;
        private System.Windows.Forms.Label b_Pawn2;
        private System.Windows.Forms.Label b_Pawn3;
        private System.Windows.Forms.Label b_Pawn4;
        private System.Windows.Forms.Label b_Pawn5;
        private System.Windows.Forms.Label b_Pawn6;
        private System.Windows.Forms.Label b_Pawn7;
        private System.Windows.Forms.Label b_Pawn8;
        private System.Windows.Forms.Label b_Pawn1;
        private System.Windows.Forms.Label w_Knight1;
        private System.Windows.Forms.Label w_Bishop1;
        private System.Windows.Forms.Label w_King;
        private System.Windows.Forms.Label w_Queen;
        private System.Windows.Forms.Label w_Bishop2;
        private System.Windows.Forms.Label w_Knight2;
        private System.Windows.Forms.Label w_Rook2;
        private System.Windows.Forms.Label w_Rook1;
        private System.Windows.Forms.Label b_Knight1;
        private System.Windows.Forms.Label b_Bishop1;
        private System.Windows.Forms.Label b_Queen;
        private System.Windows.Forms.Label b_King;
        private System.Windows.Forms.Label b_Bishop2;
        private System.Windows.Forms.Label b_Knight2;
        private System.Windows.Forms.Label b_Rook2;
        private System.Windows.Forms.Label b_Rook1;
        private System.Windows.Forms.PictureBox sqr00;
        private System.Windows.Forms.PictureBox sqr01;
        private System.Windows.Forms.PictureBox sqr02;
        private System.Windows.Forms.PictureBox sqr03;
        private System.Windows.Forms.PictureBox sqr04;
        private System.Windows.Forms.PictureBox sqr05;
        private System.Windows.Forms.PictureBox sqr06;
        private System.Windows.Forms.PictureBox sqr07;
        private System.Windows.Forms.PictureBox sqr16;
        private System.Windows.Forms.PictureBox sqr17;
        private System.Windows.Forms.PictureBox sqr14;
        private System.Windows.Forms.PictureBox sqr15;
        private System.Windows.Forms.PictureBox sqr12;
        private System.Windows.Forms.PictureBox sqr13;
        private System.Windows.Forms.PictureBox sqr10;
        private System.Windows.Forms.PictureBox sqr11;
        private System.Windows.Forms.PictureBox sqr36;
        private System.Windows.Forms.PictureBox sqr37;
        private System.Windows.Forms.PictureBox sqr34;
        private System.Windows.Forms.PictureBox sqr35;
        private System.Windows.Forms.PictureBox sqr32;
        private System.Windows.Forms.PictureBox sqr33;
        private System.Windows.Forms.PictureBox sqr30;
        private System.Windows.Forms.PictureBox sqr31;
        private System.Windows.Forms.PictureBox sqr26;
        private System.Windows.Forms.PictureBox sqr27;
        private System.Windows.Forms.PictureBox sqr24;
        private System.Windows.Forms.PictureBox sqr25;
        private System.Windows.Forms.PictureBox sqr22;
        private System.Windows.Forms.PictureBox sqr23;
        private System.Windows.Forms.PictureBox sqr20;
        private System.Windows.Forms.PictureBox sqr21;
        private System.Windows.Forms.PictureBox sqr76;
        private System.Windows.Forms.PictureBox sqr77;
        private System.Windows.Forms.PictureBox sqr74;
        private System.Windows.Forms.PictureBox sqr75;
        private System.Windows.Forms.PictureBox sqr72;
        private System.Windows.Forms.PictureBox sqr73;
        private System.Windows.Forms.PictureBox sqr70;
        private System.Windows.Forms.PictureBox sqr71;
        private System.Windows.Forms.PictureBox sqr66;
        private System.Windows.Forms.PictureBox sqr67;
        private System.Windows.Forms.PictureBox sqr64;
        private System.Windows.Forms.PictureBox sqr65;
        private System.Windows.Forms.PictureBox sqr62;
        private System.Windows.Forms.PictureBox sqr63;
        private System.Windows.Forms.PictureBox sqr60;
        private System.Windows.Forms.PictureBox sqr61;
        private System.Windows.Forms.PictureBox sqr56;
        private System.Windows.Forms.PictureBox sqr57;
        private System.Windows.Forms.PictureBox sqr54;
        private System.Windows.Forms.PictureBox sqr55;
        private System.Windows.Forms.PictureBox sqr52;
        private System.Windows.Forms.PictureBox sqr53;
        private System.Windows.Forms.PictureBox sqr50;
        private System.Windows.Forms.PictureBox sqr51;
        private System.Windows.Forms.PictureBox sqr46;
        private System.Windows.Forms.PictureBox sqr47;
        private System.Windows.Forms.PictureBox sqr44;
        private System.Windows.Forms.PictureBox sqr45;
        private System.Windows.Forms.PictureBox sqr42;
        private System.Windows.Forms.PictureBox sqr43;
        private System.Windows.Forms.PictureBox sqr40;
        private System.Windows.Forms.PictureBox sqr41;
        private System.Windows.Forms.Button btn_playCC;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.ComboBox cmd_mode;
        private System.Windows.Forms.ListBox lst_stats;
        private System.Windows.Forms.Button btn_PlayHH;
        private System.Windows.Forms.ListBox listBox1;
    }
}

