﻿/*Programmer: Matthew S. van Hoose
 *Date Started: March 11, 2018
 *Last Modified: April 23, 2018
 *Course: CS461 AI
 *School: University of Southern Indiana
*/
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vanHoose_ChessPlayer_V2{
    class gameManager{
        private string[,] board = new string[8, 8] { { "WR1", "WN1", "WH1", "WK1", "WQ1", "WH2", "WN2", "WR2" },
                                                     { "WP1", "WP2", "WP3", "WP4", "WP5", "WP6", "WP7", "WP8" },
                                                     { "000", "000", "000", "000", "000", "000", "000", "000" },
                                                     { "000", "000", "000", "000", "000", "000", "000", "000" },
                                                     { "000", "000", "000", "000", "000", "000", "000", "000" },
                                                     { "000", "000", "000", "000", "000", "000", "000", "000" },
                                                     { "BP1", "BP2", "BP3", "BP4", "BP5", "BP6", "BP7", "BP8" },
                                                     { "BR1", "BN1", "BH1", "BQ1", "BK1", "BH2", "BN2", "BR2" }};

        private string[,] whitePieces = new string[16, 3] { { "WR1", "0", "0" },
                                                            { "WN1", "0", "1" },
                                                            { "WH1", "0", "2" },
                                                            { "WK1", "0", "3" },
                                                            { "WQ1", "0", "4" },
                                                            { "WH2", "0", "5" },
                                                            { "WN2", "0", "6" },
                                                            { "WR2", "0", "7" },
                                                            { "WP1", "1", "0" },
                                                            { "WP2", "1", "1" },
                                                            { "WP3", "1", "2" },
                                                            { "WP4", "1", "3" },
                                                            { "WP5", "1", "4" },
                                                            { "WP6", "1", "5" },
                                                            { "WP7", "1", "6" },
                                                            { "WP8", "1", "7" }};

        private string[,] blackPieces = new string[16, 3] { { "BR1", "6", "0" },
                                                            { "BN1", "6", "1" },
                                                            { "BH1", "6", "2" },
                                                            { "BK1", "6", "3" },
                                                            { "BQ1", "6", "4" },
                                                            { "BH2", "6", "5" },
                                                            { "BN2", "6", "6" },
                                                            { "BR2", "6", "7" },
                                                            { "BP1", "7", "0" },
                                                            { "BP2", "7", "1" },
                                                            { "BP3", "7", "2" },
                                                            { "BP4", "7", "3" },
                                                            { "BP5", "7", "4" },
                                                            { "BP6", "7", "5" },
                                                            { "BP7", "7", "6" },
                                                            { "BP8", "7", "7" }};

        private string currentPlayer = "White";
        private bool kingTaken = false;

        private List<Control> formElementPieces = new List<Control>();
        public gameManager(){
        }//End constructor

        public void setElementList(List<Control> formPieceList) {
            formElementPieces = formPieceList;
        }//End setElementList

        public string getCurrentPlayer() {
            return currentPlayer;
        }//End getCurrentPlayer

        public void setCurrentPlayer(string curPlayer) {
            currentPlayer = curPlayer;
        }//End setCurrentPlayer

        public string[,] getBoard() {
            return board;
        }//End getBoard

        public bool getKingStatus() {
            return kingTaken;
        }//End getKingStatus

        public void resetKingStatus() {
            kingTaken = false;
        }//End resetKingStatus

        public void setBoard() { 
            string[,] resetBoard = new string[8, 8] { { "WR1", "WN1", "WH1", "WK1", "WQ1", "WH2", "WN2", "WR2" },
                                                         { "WP1", "WP2", "WP3", "WP4", "WP5", "WP6", "WP7", "WP8" },
                                                         { "000", "000", "000", "000", "000", "000", "000", "000" },
                                                         { "000", "000", "000", "000", "000", "000", "000", "000" },
                                                         { "000", "000", "000", "000", "000", "000", "000", "000" },
                                                         { "000", "000", "000", "000", "000", "000", "000", "000" },
                                                         { "BP1", "BP2", "BP3", "BP4", "BP5", "BP6", "BP7", "BP8" },
                                                         { "BR1", "BN1", "BH1", "BQ1", "BK1", "BH2", "BN2", "BR2" }};
            string[,] resetWhitePieces = new string[16, 3] { { "WR1", "0", "0" },
                                                            { "WN1", "0", "1" },
                                                            { "WH1", "0", "2" },
                                                            { "WK1", "0", "3" },
                                                            { "WQ1", "0", "4" },
                                                            { "WH2", "0", "5" },
                                                            { "WN2", "0", "6" },
                                                            { "WR2", "0", "7" },
                                                            { "WP1", "1", "0" },
                                                            { "WP2", "1", "1" },
                                                            { "WP3", "1", "2" },
                                                            { "WP4", "1", "3" },
                                                            { "WP5", "1", "4" },
                                                            { "WP6", "1", "5" },
                                                            { "WP7", "1", "6" },
                                                            { "WP8", "1", "7" }};

            string[,] resetBlackPieces = new string[16, 3] { { "BR1", "6", "0" },
                                                            { "BN1", "6", "1" },
                                                            { "BH1", "6", "2" },
                                                            { "BK1", "6", "3" },
                                                            { "BQ1", "6", "4" },
                                                            { "BH2", "6", "5" },
                                                            { "BN2", "6", "6" },
                                                            { "BR2", "6", "7" },
                                                            { "BP1", "7", "0" },
                                                            { "BP2", "7", "1" },
                                                            { "BP3", "7", "2" },
                                                            { "BP4", "7", "3" },
                                                            { "BP5", "7", "4" },
                                                            { "BP6", "7", "5" },
                                                            { "BP7", "7", "6" },
                                                            { "BP8", "7", "7" }};

            board = resetBoard;
            whitePieces = resetWhitePieces;
            blackPieces = resetBlackPieces;

            foreach (Control element in formElementPieces) {
                element.Visible = true;
            }//End foreach
        }//End setBoard

        public void test() {
            foreach (Control element in formElementPieces) {
                MessageBox.Show(element.Tag.ToString() + ": " + element.Location.X.ToString() + "," + element.Location.Y.ToString());
            }
        }

        public int[] getPieceLocation(string pieceTag) {
            int[] pieceIndex = new int[2];
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++){
                    if(board[i,j].Equals(pieceTag)){
                        pieceIndex[0] = i;
                        pieceIndex[1] = j;
                        break;
                    }//End if
                }//End Forloop j
            }//End Forloop i
            return pieceIndex;
        }//End getPieceLocation

        public void removeTakenPiece() {
            List<string> pieceList = new List<string>();
            List<string> allPieceFromBoard = new List<string>();
            string needToRemove = "";
            for (int i = 0; i < 16; i++) {
                pieceList.Add(whitePieces[i, 0]);
                pieceList.Add(blackPieces[i, 0]);
            }//End for i

            foreach (string element in board) {
                allPieceFromBoard.Add(element);
            }//End foreach
            
            allPieceFromBoard.RemoveAll(item => item == "000");

            for (int i = 0; i < pieceList.Count; i++) {
                if (!allPieceFromBoard.Contains(pieceList[i])) {
                    needToRemove = pieceList[i];
                    foreach (Control element in formElementPieces) {
                        if (element.Tag.Equals(needToRemove)) {
                            element.Visible = false;
                        }//End if
                    }//End foreach
                }//End if
            }//End for i
            //printboard();
        }//End removePiece

        public List<string> getLocationToHighlight(string pieceTag, int x, int y) {
            List<string> locations = new List<string>();
            chessMovements findMoves = new chessMovements(pieceTag, x, y);
            locations = removeIllegalMoves(findMoves.getLocations(), pieceTag);
            List<string> tempList = locations;
            return locations;
        }//End getLocationToHighlight

        public List<string> unPackSet(List<List<string>> listSet) {
            List<string> unPackedList = new List<string>();
            for (int i = 0; i < listSet.Count; i++) {
                for (int j = 0; j < listSet[i].Count; j++){
                    unPackedList.Add(listSet[i][j]);
                }//End for j
            }//End for i
            return unPackedList;
        }//End unPackSet

        public List<string> removeIllegalMoves(List<List<string>> knownMoves, string pieceTag) {
            List<string> finalLocations = new List<string>();
            List<string> pieceLocations = getCurrentPieceLocations(pieceTag);
            for (int i = 0; i < knownMoves.Count; i++) {
                for (int j = 0; j < knownMoves[i].Count; j++) {
                    if (knownMoves[i][j].Contains("-") || (knownMoves[i][j].Length >= 3) || (int.Parse(knownMoves[i][j].Substring(0, 1)) >= 8) || (int.Parse(knownMoves[i][j].Substring(1, 1)) >= 8)){
                        knownMoves[i][j] = "N";
                    }//End if
                }//End for j
                knownMoves[i].RemoveAll(s => s.StartsWith("N"));
            }//End for i
            knownMoves = removeBlockedMoves(knownMoves, pieceTag);
            for (int i = 0; i < knownMoves.Count; i++) {
                for (int j = 0; j < knownMoves[i].Count; j++){
                    if (pieceLocations.Contains(knownMoves[i][j])) {
                        knownMoves[i][j] = "N";
                    }//End if
                }//End for j
                knownMoves[i].RemoveAll(s => s.StartsWith("N"));
            }//End for i
            finalLocations = unPackSet(knownMoves);
            return finalLocations;
        }//End removeIllegalMoves

        public List<List<string>> removeBlockedMoves(List<List<string>> knownMoves, string pieceTag){
            List<List<string>> finalLocations = knownMoves;
            string tag = "";
            if (pieceTag.Contains("B")){
                tag = "WWW";
            }else {
                tag = "BBB";
            }//End if
            List<string> pieceLocations = getCurrentPieceLocations(tag);
            bool blocked = false;
            for (int i = 0; i < finalLocations.Count; i++) {
                blocked = false;
                for (int j = 0; j < finalLocations[i].Count; j++) {
                    if (blocked == true) {
                        finalLocations[i][j] = "N";
                    }else{
                        if (pieceLocations.Contains(finalLocations[i][j])) {
                            blocked = true;
                        }//End if
                    }//End if
                }//End for j
            }//End for i

            pieceLocations = getCurrentPieceLocations(pieceTag);
            for (int i = 0; i < finalLocations.Count; i++) {
                blocked = false;
                for (int j = 0; j < finalLocations[i].Count; j++) {
                    if (blocked == true) {
                        finalLocations[i][j] = "N";
                    }else{
                        if (pieceLocations.Contains(finalLocations[i][j])) {
                            blocked = true;
                        }//End if
                    }//End if
                }//End for j
            }//End for i
            return finalLocations;
        }//End removeBlockMovies

        public List<string> getCurrentPieceLocations(string pieceTag) {
            List<string> allLocations = new List<string>();
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if (!board[i, j].Equals("000")){
                        if (board[i, j].Contains(pieceTag.Substring(0, 1))) {
                            allLocations.Add(i.ToString()+j.ToString());
                        }//End if
                    }//End if
                }//End for j
            }//End for i
            return allLocations;
        }//End getCurrentPieveLocations

        public void updatePieceList(string pieceTag, int x, int y){
            string[,] updatedPieceArray = new string[16, 3];
            string type = "";
            if (whitePieces[1,0].Substring(0, 1).Equals(pieceTag.Substring(0, 1))) {
                updatedPieceArray = whitePieces;
                type = "W";
            }else{
                updatedPieceArray = blackPieces;
                type = "B";
            }//End if
            for (int i = 0; i < 16; i++) {
                if (updatedPieceArray[i, 0].Equals(pieceTag)) {
                    updatedPieceArray[i, 1] = x.ToString();
                    updatedPieceArray[i, 2] = y.ToString();
                    break;
                }//End if
            }//End for i
            if (type.Equals("W")) {
                whitePieces = updatedPieceArray;
            }else{
                blackPieces = updatedPieceArray;
            }//End if
        }//End updatePieceLis 

        public void checkForKing() { 
            List<string> allPieceFromBoard = new List<string>();
            foreach (string element in board) {
                allPieceFromBoard.Add(element);
            }//End foreach
            if (!allPieceFromBoard.Contains("WK1")) {
                MessageBox.Show("BLACK WINS");
                kingTaken = true;
            }//End if
            if (!allPieceFromBoard.Contains("BK1")) {
                MessageBox.Show("WHITE WINS");
                kingTaken = true;
            }//End if
        }//End checkForKing

        public void nextPlayer() {
            if (currentPlayer.Equals("White")) {
                currentPlayer = "Black";
            }else{
                currentPlayer = "White";
            }//End If
            //MessageBox.Show(currentPlayer);
        }//End nextPlayer

        public void movePieceAuto(string pieceTag, int x, int y) {
            foreach (Control element in formElementPieces) {
                if (element.Tag.Equals(pieceTag)) {
                    element.Location = new Point(((y * 64) + 11), ((x * 64) + 12));
                    break;
                }
            }
        }

        public void updateBoard(string pieceTag, int x, int y) {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if (board[i, j].Contains(pieceTag)){
                        board[i, j] = "000";
                        break;
                    }//End if
                }//End for i
            }//End for j
            updatePieceList(pieceTag, x, y);
            board[x, y] = pieceTag;
            removeTakenPiece();
            nextPlayer();
            checkForKing();
        }//End updateBoard
    }//End Class
}//Namespace
