﻿/*Programmer: Matthew S. van Hoose
 *Date Started: March 11, 2018
 *Last Modified: April 23, 2018
 *Course: CS461 AI
 *School: University of Southern Indiana
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.PowerPacks;

namespace vanHoose_ChessPlayer_V2{
    public partial class Form1 : Form{
        static gameManager manager = new gameManager();
        static Label selectedPiece = null;
        
        public Form1(){
            InitializeComponent();
            List<Control> c = Controls.OfType<Label>().Cast<Control>().ToList();
            manager.setElementList(c);
            cmd_mode.SelectedIndex = 0;
            btn_playCC.Enabled = false;
            btn_PlayHH.Enabled = true;
            cmd_mode_SelectionChangeCommitted(null, null);
        }//End Form1

        private void highLiteMove(object sender, EventArgs e) {
            unHighLiteMove();
            int[] pieceLocation = new int[2];
            try{
                Label imgBox = (Label)sender;
                selectedPiece = imgBox;
                if (imgBox.Name.Contains("Pawn")){
                    pieceLocation = manager.getPieceLocation(imgBox.Tag.ToString());
                }//End if
                if (imgBox.Name.Contains("Rook")){
                    pieceLocation = manager.getPieceLocation(imgBox.Tag.ToString());
                }//End if
                if (imgBox.Name.Contains("Bishop")){
                    pieceLocation = manager.getPieceLocation(imgBox.Tag.ToString());
                }//End if
                if (imgBox.Name.Contains("Knight")){
                    pieceLocation = manager.getPieceLocation(imgBox.Tag.ToString());
                }//End if
                if (imgBox.Name.Contains("Queen")){
                    pieceLocation = manager.getPieceLocation(imgBox.Tag.ToString());
                }//End if
                if (imgBox.Name.Contains("King")){
                    pieceLocation = manager.getPieceLocation(imgBox.Tag.ToString());
                }//End if
                List<string> toHighLite = manager.getLocationToHighlight(imgBox.Tag.ToString(), pieceLocation[0], pieceLocation[1]);
                List<Control> c = Controls.OfType<PictureBox>().Cast<Control>().ToList();
                foreach (Control element in c){
                    if (toHighLite.Contains(element.Tag.ToString().Substring(1))){
                        element.BackColor = Color.Green;
                    }//End if
                }//End foreach
            }//End try
            catch{
                MessageBox.Show("Oh, Snap! Something Went Wrong!");
            }//End Catch
        }//End highLiteMove

        private void unHighLiteMove() {
            List<Control> c = Controls.OfType<PictureBox>().Cast<Control>().ToList();
            foreach (Control element in c) {
                if (element.Tag.ToString().Contains("B")){
                    element.BackColor = Color.Black;
                }else{
                    element.BackColor = Color.White;
                }//End if
            }//End foreach
        }//End unHighLiteMove

        private void selectMove(object sender, EventArgs e) {
            PictureBox imgBox = (PictureBox)sender;
            int newX = int.Parse(imgBox.Tag.ToString().Substring(1, 1));
            int newY = int.Parse(imgBox.Tag.ToString().Substring(2, 1));
            if (imgBox.BackColor == Color.Green) {
                selectedPiece.Location = new Point(((newY*64)+11), ((newX*64)+12));
                manager.updateBoard(selectedPiece.Tag.ToString(), newX, newY);
                unHighLiteMove();
                selectedPiece = null;
                changePlayer();
                if (manager.getKingStatus() == true) {
                    countWins();
                    manager.resetKingStatus();
                    manager.setBoard();
                    resetLocations();
                }//End if
            }//End if
            countPieces();
        }//End selectMove

        private void countPieces() {
            string[,] board = manager.getBoard();
            int whiteCount = 0;
            int blackCount = 0;
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if (board[i, j].Contains("B")) {
                        blackCount++;
                    }else if(board[i,j].Contains("W")){
                        whiteCount++;
                    }//End if
                }//End for j
            }//End for i
            lst_stats.Items[4] = whiteCount.ToString();
            lst_stats.Items[7] = blackCount.ToString();
        }//End countPieces

        private void btn_reset_Click(object sender, EventArgs e){
            manager.setBoard();
            resetLocations();
            lst_stats.Items[1] = "White";
            cmd_mode_SelectionChangeCommitted(null, null);
        }//End btn_reset

        private void changePlayer() {
            List<Control> c = Controls.OfType<Label>().Cast<Control>().ToList();
            if (lst_stats.Items[1].ToString().Contains("W")) {
                foreach (Control element in c) {
                    if (element.Tag.ToString().Contains("W")) {
                        element.Enabled = false;
                    }else if(element.Tag.ToString().Contains("B")){
                        element.Enabled = true;
                    }//End if
                }//End foreach
                lst_stats.Items[1] = "Black";
                manager.setCurrentPlayer("Black");
            }else if (lst_stats.Items[1].ToString().Contains("B")) {
                foreach (Control element in c) {
                    if (element.Tag.ToString().Contains("B")) {
                        element.Enabled = false;
                    }else if(element.Tag.ToString().Contains("W")){
                        element.Enabled = true;
                    }//End if
                }//End foreach
                lst_stats.Items[1] = "White";
                manager.setCurrentPlayer("White");
            }//End if
        }//End changePlayer

        private void cmd_mode_SelectionChangeCommitted(object sender, EventArgs e){
            List<Control> c = Controls.OfType<Label>().Cast<Control>().ToList();
            manager.setBoard();
            resetLocations();
            unHighLiteMove();
            if (cmd_mode.SelectedIndex == 1) {//Computer vs. Computer
                foreach (Control element in c) {
                    if (element.Tag.ToString().Substring(0, 1).Equals("B") || element.Tag.ToString().Substring(0, 1).Equals("W")) {
                        element.Enabled = false;
                        btn_playCC.Enabled = true;
                        btn_PlayHH.Enabled = false;
                    }//End if
                }//End foreach
            }//End if
            if (cmd_mode.SelectedIndex == 0) {//Human vs. Human
                foreach (Control element in c) {
                    if (element.Tag.ToString().Substring(0, 1).Equals("W")) {
                        element.Enabled = true;
                        btn_playCC.Enabled = false;
                        btn_PlayHH.Enabled = true;
                    }//End if
                    if (element.Tag.ToString().Substring(0, 1).Equals("B")) {
                        element.Enabled = false;
                    }//End if
                }//End foreach
            }//End if
        }//End resetLocation

        private void countWins() {
            string winner = manager.getCurrentPlayer();
            if (winner.Equals("White")){
                int whiteWins = int.Parse(lst_stats.Items[10].ToString());
                whiteWins += 1;
                lst_stats.Items[10] = whiteWins.ToString();
            }else if (winner.Equals("Black")){
                int blackWins = int.Parse(lst_stats.Items[13].ToString());
                blackWins += 1;
                lst_stats.Items[10] = blackWins.ToString();
            }//End if
        }//ENd countWins

        private void resetLocations() {
            w_Pawn1.Location    = new Point(11, 76);
            w_Pawn2.Location    = new Point(75, 76);
            w_Pawn3.Location    = new Point(139, 76);
            w_Pawn4.Location    = new Point(203, 76);
            w_Pawn5.Location    = new Point(267, 76);
            w_Pawn6.Location    = new Point(331, 76);
            w_Pawn7.Location    = new Point(395, 76);
            w_Pawn8.Location    = new Point(459, 76);
            w_Rook1.Location    = new Point(11, 12);
            w_Rook2.Location    = new Point(459, 12);
            w_Knight1.Location  = new Point(75, 12);
            w_Knight2.Location  = new Point(395, 12);
            w_Bishop1.Location  = new Point(139, 12);
            w_Bishop2.Location  = new Point(331, 12);
            w_King.Location     = new Point(203, 12);
            w_Queen.Location    = new Point(267, 12);
            b_Pawn1.Location    = new Point(11, 396);
            b_Pawn2.Location    = new Point(75, 396);
            b_Pawn3.Location    = new Point(139, 396);
            b_Pawn4.Location    = new Point(203, 396);
            b_Pawn5.Location    = new Point(267, 396);
            b_Pawn6.Location    = new Point(331, 396);
            b_Pawn7.Location    = new Point(395, 396);
            b_Pawn8.Location    = new Point(459, 396);
            b_Rook1.Location    = new Point(11, 460);
            b_Rook2.Location    = new Point(459, 460);
            b_Knight1.Location  = new Point(75, 460);
            b_Knight2.Location  = new Point(395, 460);
            b_Bishop1.Location  = new Point(139, 460);
            b_Bishop2.Location  = new Point(331, 460);
            b_King.Location     = new Point(267, 460);
            b_Queen.Location    = new Point(203, 460);
        }//End resetLocations

        private void btn_playCC_Click(object sender, EventArgs e){
            computerPlayer blackPlayer = new computerPlayer("Black", manager);
            computerPlayer whitePlayer = new computerPlayer("White", manager);
            while (manager.getKingStatus() == false) {
                lst_stats.Items[1] = "White";
                whitePlayer.update();
                this.Refresh();
                countPieces();
                System.Threading.Thread.Sleep(100);
                lst_stats.Items[1] = "Black";
                blackPlayer.update();
                this.Refresh();
                countPieces();
                System.Threading.Thread.Sleep(100);
            }//End while
            countWins();
            manager.resetKingStatus();
        }//ResetLocation
    }//End class
}//End namespace
