﻿/*Programmer: Matthew S. van Hoose
 *Date Started: March 11, 2018
 *Last Modified: April 23, 2018
 *Course: CS461 AI
 *School: University of Southern Indiana
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vanHoose_ChessPlayer_V2{
    class chessMovements{
        private string tag = "";
        private int x;
        private int y;
        private List<List<string>> finalLocations = new List<List<string>>();
        public chessMovements(string pieceTag, int locX, int locY) {
            tag = pieceTag;
            x = locX;
            y = locY;
        }//End constructor

        public List<List<string>> getLocations(){
            if (tag.Contains("P")){
                finalLocations = pawnMovement();
            }//End if
            if (tag.Contains("R")) {
                finalLocations = rookMovement();
            }//End if
            if (tag.Contains("N")) {
                finalLocations = knightMovement();
            }//End if
            if (tag.Contains("H")) {
                finalLocations = bishoptMovement();
            }//End if
            if (tag.Contains("Q")) {
                finalLocations = queenMovement();
            }//End if
            if (tag.Contains("K")) {
                finalLocations = kingMovement();
            }//End if
            return finalLocations;
        }//End getLocations

        private List<List<string>> pawnMovement(){
            List<List<string>> finalListSet = new List<List<string>>();
            List<string> locations = new List<string>();
            if (tag.Contains("B")){
                locations.Add((x - 1).ToString() + y.ToString());
                locations.Add((x - 2).ToString() + y.ToString());
            }else {
                locations.Add((x + 1).ToString() + y.ToString());
                locations.Add((x + 2).ToString() + y.ToString());
            }//End if
            finalListSet.Add(locations);
            return finalListSet;
        }//End pawnMovement

        private List<List<string>> rookMovement() {//Need to redo, dont use i for x or y
            List<List<string>> finalListSet = new List<List<string>>();
            for (int i = 0; i < 4; i++) {
                List<string> locations = new List<string>();
                for (int j = 0; j < 8; j++) {
                    if (i == 0) {
                        locations.Add((x + j).ToString() + y.ToString());
                    }else if(i == 1){
                        locations.Add((x - j).ToString() + y.ToString());
                    }else if(i == 2){
                        locations.Add(x.ToString() + (y + j).ToString());
                    }else if(i ==3){
                        locations.Add(x.ToString() + (y - j).ToString());
                    }//End if
                }//End for j
                locations.Remove(x.ToString() + y.ToString());
                finalListSet.Add(locations);
            }//End for i
            return finalListSet;
        }//End rookMovement

        private List<List<string>> knightMovement() {
            List<List<string>> finalListSet = new List<List<string>>();
            List<string> locations = new List<string>();
            locations.Add((x + 2).ToString() + (y + 1).ToString());
            locations.Add((x + 2).ToString() + (y - 1).ToString());
            locations.Add((x - 2).ToString() + (y + 1).ToString());
            locations.Add((x - 2).ToString() + (y - 1).ToString());
            locations.Add((x + 1).ToString() + (y + 2).ToString());
            locations.Add((x + 1).ToString() + (y - 2).ToString());
            locations.Add((x - 1).ToString() + (y + 2).ToString());
            locations.Add((x - 1).ToString() + (y - 2).ToString());
            foreach (string elements in locations) {
                List<string> temp = new List<string>();
                temp.Add(elements);
                finalListSet.Add(temp);
            }//End foreach
            return finalListSet;
        }//End knightMovement

        private List<List<string>> bishoptMovement() {
            List<List<string>> finalListSet = new List<List<string>>();
            for (int i = 0; i < 4; i++) {
                List<string> locations = new List<string>();
                for (int j = 0; j < 8; j++){
                    if (i == 0){
                        locations.Add((x + j).ToString() + (y + j).ToString());
                    }else if (i == 1){
                        locations.Add((x + j).ToString() + (y - j).ToString());
                    }else if (i == 2){
                        locations.Add((x - j).ToString() + (y - j).ToString());
                    }else if (i == 3){
                        locations.Add((x - j).ToString() + (y + j).ToString());
                    }//End if
                }//End for j
                locations.Remove(x.ToString() + y.ToString());
                finalListSet.Add(locations);
            }//End for i
            return finalListSet;
        }//End bishopMovement

        private List<List<string>> queenMovement() {
            List<List<string>> finalListSet = new List<List<string>>();       
            for (int i = 0; i < 8; i++) {
                List<string> locations = new List<string>();
                for (int j = 0; j < 8; j++){
                    if (i == 0){
                        locations.Add((x).ToString() + (y + j).ToString());
                    }else if (i == 1){
                        locations.Add((x).ToString() + (y - j).ToString());
                    }else if (i == 2){
                        locations.Add((x + j).ToString() + (y).ToString());
                    }else if (i == 3){
                        locations.Add((x - j).ToString() + (y).ToString());
                    }else if (i == 4){
                        locations.Add((x - j).ToString() + (y + j).ToString());
                    }else if (i == 5){
                        locations.Add((x - j).ToString() + (y - j).ToString());
                    }else if (i == 6){
                        locations.Add((x + j).ToString() + (y - j).ToString());
                    }else if (i == 7){
                        locations.Add((x + j).ToString() + (y + j).ToString());
                    }//End if
                }//End for j
                locations.Remove(x.ToString() + y.ToString());
                finalListSet.Add(locations);
            }//End for i
            return finalListSet;
        }//End queenMovement

        private List<List<string>> kingMovement(){
            List<List<string>> finalListSet = new List<List<string>>();
            List<string> locations = new List<string>();
            locations.Add((x).ToString() + (y + 1).ToString());
            locations.Add((x).ToString() + (y - 1).ToString());
            locations.Add((x + 1).ToString() + (y).ToString());
            locations.Add((x - 1).ToString() + (y).ToString());
            locations.Add((x - 1).ToString() + (y + 1).ToString());
            locations.Add((x - 1).ToString() + (y - 1).ToString());
            locations.Add((x + 1).ToString() + (y - 1).ToString());
            locations.Add((x + 1).ToString() + (y + 1).ToString());
            foreach (string elements in locations){
                List<string> temp = new List<string>();
                temp.Add(elements);
                finalListSet.Add(temp);
            }//End foreach
            return finalListSet;
        }//End kingMovement
    }//End class
}//End namespace
