﻿/*Programmer: Matthew S. van Hoose
 *Date Started: March 11, 2018
 *Last Modified: April 23, 2018
 *Course: CS461 AI
 *School: University of Southern Indiana
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vanHoose_ChessPlayer_V2{
    class computerPlayer{

        private gameManager manager;
        private List<List<string>> moves = new List<List<string>>();
        private List<string> pieces = new List<string>();
        private List<string> chosenMove = new List<string>();

        private string[,] board;

        private string playerColor;

        public computerPlayer(string color, gameManager currentGame) {
            manager = currentGame;
            board = manager.getBoard();
            playerColor = color;
        }//End constructor

        public void getMoves(){
            moves.Clear();
            board = manager.getBoard();
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if (board[i, j].Substring(0, 1).Equals(playerColor.Substring(0, 1))) {
                        pieces.Add(board[i, j]);
                    }//End if
                }//End for j
            }//End for i
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if (pieces.Contains(board[i,j])) {
                        //MessageBox.Show(board[i, j]);
                        List<string> tempList = manager.getLocationToHighlight(board[i,j], i, j);
                        //tempList.Insert(0, board[i, j]);
                        tempList.Add(board[i, j]);
                        if (tempList.Count > 1){
                            moves.Add(tempList);
                        }
                    }//End if
                }//End for j
            }//End for i
            /*
            string temp = "■ ";
            foreach (List<string> set in moves) {
                foreach (string element in set) {
                    temp = temp + element + " , ";
                }
                temp = temp + " ■";
                MessageBox.Show(temp);
                temp = "■ ";
            }
            */
        }//End getMoves

//-----------------------------------------------------------------------------------------------------------------------------------
        //THis method below is just a fillin to see if the computer is able to use the methods located in the gameManager class.
        //All this is doing is getting the moves and randomly selecting a move to the piece to go.
        //4-23-2018 : Well this makes better moves than the depth-first search WTF
        public void tempRandom() {//THIS WAS JUST A CONCEPT, THIS IS CRAP DO NOT KEEP IN!!! IMPLIMENT THE DEPTH-FIRST SEACH TREE
            try{
                Random rnd = new Random();
                //MessageBox.Show("Size of Set :" + moves.Count);
                int randNum = rnd.Next(0, moves.Count);
                List<string> temp = moves[randNum];
                string temps = "| ";
                foreach (string element in temp) {
                    temps = temps + element + " | ";
                }
                temps = temps + " |";
                MessageBox.Show(temps);
                //MessageBox.Show("Size of Set :" + temp.Count);
                randNum = rnd.Next(1, temp.Count);
                string chosen = temp[randNum];
                string piece = temp[temp.Count - 1];
                int x = int.Parse(chosen.Substring(0, 1));
                int y = int.Parse(chosen.Substring(1, 1));
                //MessageBox.Show(piece + "," + x.ToString() + "," + y.ToString());
                //manager.movePieceAuto(piece, x, y);
                manager.updateBoard(piece, x, y);
                manager.movePieceAuto(piece, x, y);
                //System.Threading.Thread.Sleep(250);
            }//End try
            catch { }//End Catch
        }//End tempRandome
//-----------------------------------------------------------------------------------------------------------------------------------

        public void update() {
            getMoves();
            Node startNode = new Node(moves, 1, manager);
            //tempRandom();
            chosenMove = startNode.startProcess();
            manager.updateBoard(chosenMove[0], int.Parse(chosenMove[1].Substring(0, 1)), int.Parse(chosenMove[1].Substring(1, 1)));
            manager.movePieceAuto(chosenMove[0], int.Parse(chosenMove[1].Substring(0, 1)), int.Parse(chosenMove[1].Substring(1, 1)));//Stoped Here
        }//End update

    }//End computerPlayer

    class Node{
        private List<List<string>> bestMoves = new List<List<string>>();
        private List<List<string>> givenMoves = new List<List<string>>();
        private List<string> levelTwoMoves = new List<string>();
        private gameManager manager;
        private int nodeLevel;
        
        public Node(List<List<string>> moves, int level, gameManager mang) {
            givenMoves = moves;
            manager = mang;
            nodeLevel = level;
        }//End constructor level 1

        public Node(List<string> moves, int level, gameManager mang) {
            levelTwoMoves = moves;
            manager = mang;
            nodeLevel = level;
        }//End constructor level 2

        public List<string> startProcess() {
            if (nodeLevel == 1) {
                foreach (List<string> set in givenMoves) {
                    if (set.Count > 1){
                        Node newNode = new Node(set, 2, manager);
                        List<string> temp = newNode.startProcess();
                        bestMoves.Add(temp);
                    }//End if
                }//End foreach
                return selectMove();
            }else{
                return checkForIntersection(levelTwoMoves);
            }//End if
        }//End startProcess

        /*
        public List<string> selectMove() {
            List<string> bestMove = new List<string>();
            int highestSeen_hValue = 0;
                foreach (List<string> set in bestMoves) {
                    if (set.Count > 0){
                        if (int.Parse(set[2]) > highestSeen_hValue){
                            bestMove.Clear();
                            bestMove = set;
                        }
                    }
                }
            return bestMove;
        }*/
        public List<string> selectMove() {
            List<string> bestMove = new List<string>();
            Random rnd = new Random();
            bestMove = bestMoves[rnd.Next(0, bestMoves.Count - 1)];
            return bestMove;
        }

        public List<string> checkForIntersection(List<string> move) {
            string[,] board = manager.getBoard();
            string piece = move[move.Count - 1];
            List<string> tempList = move;
            List<string> bestFromSet = new List<string>();
            tempList.RemoveAt(move.Count - 1);
            int hValue = 1;
            foreach (string element in tempList) {
                int x = int.Parse(element.Substring(0, 1));
                int y = int.Parse(element.Substring(1, 1));
                int temp_hVale = 1;
                if (board[x, y].Contains("K")) {
                    temp_hVale = 100;
                }else if(board[x, y].Contains("Q")){
                    temp_hVale = 50;
                }else if(board[x, y].Contains("H")){
                    temp_hVale = 25;
                }else if(board[x, y].Contains("N")){
                    temp_hVale = 15;
                }else if (board[x, y].Contains("R")) {
                    temp_hVale = 10;
                }else if (board[x, y].Contains("P")){
                    temp_hVale = 2;
                }else {
                    temp_hVale = 1;
                }//End if

                if (temp_hVale >= hValue) {
                    bestFromSet.Clear();
                    hValue = temp_hVale;
                    bestFromSet.Add(piece);
                    bestFromSet.Add(x.ToString() + y.ToString());
                    bestFromSet.Add(hValue.ToString());
                }//End if
            }//End foreach
            return bestFromSet;
        }//End checkForIntersection
    }//End Node
}//End Namespace
